import 'package:flutter/material.dart';

void main() => runApp(const GulufApp());

const gulufGreen = Color(0xFF087F5B);
const gulufDark = Color(0xFF103B32);
const gulufCream = Color(0xFFF5F7F4);

class GulufApp extends StatelessWidget {
  const GulufApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GULUF Taxi',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: gulufGreen),
        scaffoldBackgroundColor: gulufCream,
        appBarTheme: const AppBarTheme(
          backgroundColor: gulufDark,
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const RolePage(),
    );
  }
}

class Ride {
  Ride({required this.pickup, required this.destination, required this.fare});
  final String pickup;
  final String destination;
  final int fare;
  String status = 'Dalab cusub';
}

class RideStore {
  static final List<Ride> rides = [];
}

class RolePage extends StatelessWidget {
  const RolePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 26),
              Container(
                width: 76,
                height: 76,
                decoration: BoxDecoration(
                  color: gulufGreen,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: const Icon(Icons.local_taxi, color: Colors.white, size: 42),
              ),
              const SizedBox(height: 20),
              const Text('GULUF', style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900, color: gulufDark, letterSpacing: 2)),
              const Text('TAXI • BOSASO', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 2, color: gulufGreen)),
              const SizedBox(height: 12),
              const Text('Safarkaaga, si fudud.', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              const Text('Dooro qaybta aad rabto inaad isticmaasho. Tani waa nooca tijaabada ah ee GULUF.', style: TextStyle(color: Colors.black54, height: 1.4)),
              const SizedBox(height: 26),
              _RoleCard(icon: Icons.person_pin_circle, title: 'Macmiil', subtitle: 'Dalbo taxi oo geli meesha aad u socoto', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PassengerPage()))),
              const SizedBox(height: 12),
              _RoleCard(icon: Icons.drive_eta, title: 'Darawal', subtitle: 'Eeg dalabyada oo aqbal safar', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DriverPage()))),
              const SizedBox(height: 12),
              _RoleCard(icon: Icons.admin_panel_settings, title: 'Maamulka shirkadda', subtitle: 'La soco safarrada iyo qiimayaasha', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPage()))),
              const Spacer(),
              const Center(child: Text('GULUF Taxi • Bosaso', style: TextStyle(color: Colors.black45, fontSize: 12))),
            ],
          ),
        ),
      ),
    );
  }
}

class _RoleCard extends StatelessWidget {
  const _RoleCard({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
    elevation: 0,
    color: Colors.white,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      leading: CircleAvatar(backgroundColor: const Color(0xFFE4F3EC), child: Icon(icon, color: gulufGreen)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
      subtitle: Padding(padding: const EdgeInsets.only(top: 4), child: Text(subtitle)),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    ),
  );
}

class PassengerPage extends StatefulWidget {
  const PassengerPage({super.key});
  @override
  State<PassengerPage> createState() => _PassengerPageState();
}

class _PassengerPageState extends State<PassengerPage> {
  final pickup = TextEditingController(text: 'Bartamaha Bosaso');
  final destination = TextEditingController();
  int fare = 3;

  @override
  void dispose() { pickup.dispose(); destination.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Dalbo taxi')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: gulufDark, borderRadius: BorderRadius.circular(20)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(Icons.location_on, color: Colors.white, size: 32),
          SizedBox(height: 12),
          Text('Xaggee ayaad u socotaa?', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
          SizedBox(height: 6),
          Text('Geli meesha lagaa qaadayo iyo meesha aad u socoto.', style: TextStyle(color: Colors.white70)),
        ]),
      ),
      const SizedBox(height: 20),
      const Text('Meesha lagaa qaadayo', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      TextField(controller: pickup, decoration: const InputDecoration(prefixIcon: Icon(Icons.my_location), hintText: 'Tusaale: Bartamaha Bosaso')),
      const SizedBox(height: 16),
      const Text('Meesha aad u socoto', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      TextField(controller: destination, decoration: const InputDecoration(prefixIcon: Icon(Icons.location_on_outlined), hintText: 'Geli goobta aad u socoto')),
      const SizedBox(height: 20),
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
        child: Row(children: [
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Qiime qiyaas ah', style: TextStyle(color: Colors.black54)), SizedBox(height: 4), Text('Qiimaha tijaabada', style: TextStyle(fontWeight: FontWeight.bold))])),
          DropdownButton<int>(value: fare, items: const [DropdownMenuItem(value: 3, child: Text('\$3')), DropdownMenuItem(value: 5, child: Text('\$5')), DropdownMenuItem(value: 7, child: Text('\$7')), DropdownMenuItem(value: 10, child: Text('\$10'))], onChanged: (v) => setState(() => fare = v ?? 3)),
        ]),
      ),
      const SizedBox(height: 22),
      FilledButton.icon(
        style: FilledButton.styleFrom(backgroundColor: gulufGreen, minimumSize: const Size.fromHeight(54)),
        icon: const Icon(Icons.local_taxi),
        label: const Text('Dalbo taxi', style: TextStyle(fontWeight: FontWeight.bold)),
        onPressed: () {
          if (pickup.text.trim().isEmpty || destination.text.trim().isEmpty) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Fadlan buuxi labada goobood.')));
            return;
          }
          RideStore.rides.add(Ride(pickup: pickup.text.trim(), destination: destination.text.trim(), fare: fare));
          showDialog(context: context, builder: (_) => AlertDialog(
            title: const Text('Dalabka waa la sameeyay (demo)'),
            content: Text('Ka: ${pickup.text}\nKu: ${destination.text}\nQiime: \$$fare\n\nNoocan tijaabada ah, dalabku wuxuu ku muuqanayaa shaashadda darawalka isla telefoonkan.'),
            actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Haye'))],
          ));
        },
      ),
      const SizedBox(height: 12),
      const Text('Ogow: qiimaha halkan waa tusaale; ma aha qiime rasmi ah oo shirkaddu dejisay.', style: TextStyle(color: Colors.black54, fontSize: 12)),
    ]),
  );
}

class DriverPage extends StatefulWidget {
  const DriverPage({super.key});
  @override
  State<DriverPage> createState() => _DriverPageState();
}

class _DriverPageState extends State<DriverPage> {
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Shaashadda darawalka')),
    body: RideStore.rides.isEmpty
      ? const Center(child: Padding(padding: EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.local_taxi, size: 54, color: gulufGreen), SizedBox(height: 12), Text('Weli dalab ma jiro', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), SizedBox(height: 8), Text('Marka macmiilku dalab sameeyo isla app-kan, halkan ayuu ka muuqan doonaa demo ahaan.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54))])))
      : ListView(padding: const EdgeInsets.all(16), children: [
        for (final ride in RideStore.rides)
          Card(color: Colors.white, child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [const Icon(Icons.route, color: gulufGreen), const SizedBox(width: 8), Expanded(child: Text('${ride.pickup} → ${ride.destination}', style: const TextStyle(fontWeight: FontWeight.bold)))]),
            const SizedBox(height: 8),
            Text('Qiime: \$${ride.fare}  •  Xaalad: ${ride.status}'),
            const SizedBox(height: 12),
            Wrap(spacing: 8, children: [
              FilledButton(onPressed: () => setState(() => ride.status = 'Darawalku aqbalay'), child: const Text('Aqbal')),
              OutlinedButton(onPressed: () => setState(() => ride.status = 'La diiday'), child: const Text('Diid')),
            ]),
          ]))),
      ]),
  );
}

class AdminPage extends StatefulWidget {
  const AdminPage({super.key});
  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  @override
  Widget build(BuildContext context) {
    final total = RideStore.rides.fold<int>(0, (sum, ride) => sum + ride.fare);
    return Scaffold(
      appBar: AppBar(title: const Text('Maamulka GULUF')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        const Text('Warbixinta guud', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: gulufDark)),
        const SizedBox(height: 6),
        const Text('Tirooyinkani waa xog demo oo ku jirta telefoonkan oo keliya.', style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 18),
        Row(children: [
          Expanded(child: _StatCard(label: 'Safarrada', value: '${RideStore.rides.length}', icon: Icons.route)),
          const SizedBox(width: 12),
          Expanded(child: _StatCard(label: 'Qiime guud', value: '\$$total', icon: Icons.payments)),
        ]),
        const SizedBox(height: 20),
        const Text('Dalabyada', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        const SizedBox(height: 8),
        if (RideStore.rides.isEmpty)
          const Card(color: Colors.white, child: Padding(padding: EdgeInsets.all(18), child: Text('Dalabyo wali lama helin.')))
        else
          for (final ride in RideStore.rides)
            Card(color: Colors.white, child: ListTile(
              leading: const Icon(Icons.local_taxi, color: gulufGreen),
              title: Text('${ride.pickup} → ${ride.destination}'),
              subtitle: Text('${ride.status} • \$${ride.fare}'),
            )),
        const SizedBox(height: 20),
        const Text('Waxyaabaha weli loo baahan yahay ka hor isticmaalka dhabta ah:', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('• Akoonno iyo gelitaan ammaan ah\n• Database online ah oo isku xira telefoonada\n• Khariidad iyo goobta GPS\n• Qiime rasmi ah iyo lacag-bixin\n• Tijaabo darawal/macmiil iyo ilaalinta xogta'),
      ]),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.label, required this.value, required this.icon});
  final String label;
  final String value;
  final IconData icon;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: gulufGreen, size: 26),
      const SizedBox(height: 12),
      Text(value, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: gulufDark)),
      Text(label, style: const TextStyle(color: Colors.black54)),
    ]),
  );
}
