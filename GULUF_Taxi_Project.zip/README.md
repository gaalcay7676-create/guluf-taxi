# GULUF Taxi — Flutter starter project

This is a **demo starter**, not a production-ready taxi service.

## Included
- Somali-language role selection: Passenger, Driver, Company Admin
- Passenger can enter pickup/destination and submit a demo request
- Driver can accept/reject demo requests
- Admin can see demo ride count and total sample fares
- Bosaso branding

## Important limitations
- Demo ride data is stored only in memory on one running app; separate phones will NOT share rides.
- No Firebase/backend, login, real GPS, maps, push notifications, online payments, or live dispatch is connected.
- The displayed fare options are examples, not official GULUF prices.
- Do not use this build for real customer trips until backend, security, privacy, and real-device testing are completed.

## Build an Android APK
1. Install Flutter SDK on a computer and Android Studio.
2. Unzip this project.
3. In the project folder run:
   - `flutter pub get`
   - `flutter run` to test
   - `flutter build apk --release` to build an APK
4. The APK is normally created at `build/app/outputs/flutter-apk/app-release.apk`.

A computer with Flutter/Android build tools is required for the standard APK build. An Android phone alone is not enough to compile this Flutter project locally.
