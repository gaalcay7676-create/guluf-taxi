# GULUF TAXI — Android Flutter project

GULUF TAXI waa hal app Flutter ah oo leh saddex qaybood:
- **Macmiil:** dalbo taxi, dooro goobaha, dooro qiime demo ah, oo la soco xaaladda dalabka.
- **Darawal:** arag dalabyada, aqbal/diid, bilow safarka, kuna calaamadee inuu dhammaaday.
- **Maamulka:** arag tirada dalabyada iyo qiimaha safarrada dhammaaday.

## Xaaladda hadda
Shaashadaha iyo socodka demo-ga ayaa la diyaariyey. Dalabyadu waxay ku jiraan xusuusta app-ka, waxayna ku wada muuqdaan qaybaha kala duwan marka lagu isticmaalo isla app instance-ka. Marka app-ka la xiro, xogtu way lumi kartaa. Telefoonno kala duwan weli iskuma xirna.

**Weli ma aha adeeg taxi oo diyaar u ah macaamiil dhab ah.** Waxaa maqan backend/database online ah, aqoonsi iyo login ammaan ah, GPS/khariidad dhab ah, ogeysiisyo, xisaabinta qiime rasmi ah, lacag-bixin iyo tijaabo qalab.

## Dhisidda APK
Waxaa loo baahan yahay Flutter SDK iyo Android SDK ama GitHub Actions.

### Kombiyuutar
1. Fur galka mashruuca.
2. Orod `flutter create --platforms=android .` si loo abuuro faylasha Android.
3. Orod `flutter pub get`.
4. Orod `flutter analyze`.
5. Orod `flutter build apk --release`.
6. APK: `build/app/outputs/flutter-apk/app-release.apk`.

### GitHub Actions
Workflow-ga `.github/workflows/build-android.yml` wuxuu dhisayaa APK marka la riixo `main` ama si gacanta ah loo bilaabo.
1. Ku geli faylasha mashruuca repository-ga GitHub.
2. Fur tab-ka **Actions**.
3. Dooro **Build GULUF Taxi Android APK** oo taabo **Run workflow**, ama sug build-ka push-ka.
4. Marka build-ku guulaysto, ka soo dejiso `guluf-taxi-release-apk` qaybta Artifacts.

APK-ga waa in build-ku guulaysto oo lagu tijaabiyaa Android ka hor inta aan loo qaybin dadka.
