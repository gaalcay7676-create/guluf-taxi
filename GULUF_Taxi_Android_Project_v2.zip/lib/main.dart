import 'package:flutter/material.dart';

void main() => runApp(const GulufApp());

const gulufGreen = Color(0xFF087F5B);
const gulufDark = Color(0xFF103B32);
const gulufCream = Color(0xFFF5F7F4);

class GulufApp extends StatelessWidget {
  const GulufApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'GULUF Taxi',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: gulufGreen),
          scaffoldBackgroundColor: gulufCream,
          appBarTheme: const AppBarTheme(
            backgroundColor: gulufDark,
            foregroundColor: Colors.white,
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        home: const RolePage(),
      );
}

enum RideStatus { requested, accepted, onTrip, completed, declined, cancelled }

extension RideStatusText on RideStatus {
  String get label => switch (this) {
        RideStatus.requested => 'Dalab cusub',
        RideStatus.accepted => 'Darawalku aqbalay',
        RideStatus.onTrip => 'Safarku wuu socdaa',
        RideStatus.completed => 'Safarka waa dhammaaday',
        RideStatus.declined => 'La diiday',
        RideStatus.cancelled => 'La joojiyey',
      };
}

class Ride {
  Ride({
    required this.id,
    required this.pickup,
    required this.destination,
    required this.fare,
    required this.createdAt,
  });
  final int id;
  final String pickup;
  final String destination;
  final int fare;
  final DateTime createdAt;
  RideStatus status = RideStatus.requested;
}

class RideStore extends ChangeNotifier {
  RideStore._();
  static final RideStore instance = RideStore._();
  final List<Ride> rides = [];
  int _nextId = 1001;

  void createRide({required String pickup, required String destination, required int fare}) {
    rides.insert(0, Ride(
      id: _nextId++,
      pickup: pickup,
      destination: destination,
      fare: fare,
      createdAt: DateTime.now(),
    ));
    notifyListeners();
  }

  void updateStatus(Ride ride, RideStatus status) {
    ride.status = status;
    notifyListeners();
  }
}

class RolePage extends StatelessWidget {
  const RolePage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(24),
            children: [
              const SizedBox(height: 18),
              Container(
                width: 76,
                height: 76,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: gulufGreen,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: const Icon(Icons.local_taxi, color: Colors.white, size: 42),
              ),
              const SizedBox(height: 20),
              const Text('GULUF', style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900, color: gulufDark, letterSpacing: 2)),
              const Text('TAXI • BOSASO', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 2, color: gulufGreen)),
              const SizedBox(height: 12),
              const Text('Safarkaaga, si fudud.', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              const Text('Hal app gudaheed ka dooro qaybta macmiilka ama darawalka. Maamulka shirkadduna wuxuu ka arki karaa safarrada demo-ga.', style: TextStyle(color: Colors.black54, height: 1.4)),
              const SizedBox(height: 24),
              _RoleCard(icon: Icons.person_pin_circle, title: 'Macmiil', subtitle: 'Dalbo taxi, arag xaaladda safarkaaga', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PassengerPage()))),
              const SizedBox(height: 12),
              _RoleCard(icon: Icons.drive_eta, title: 'Darawal', subtitle: 'Eeg dalabyada oo maamul safarrada', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DriverPage()))),
              const SizedBox(height: 12),
              _RoleCard(icon: Icons.admin_panel_settings, title: 'Maamulka shirkadda', subtitle: 'La soco safarrada iyo qiimaha demo-ga', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPage()))),
              const SizedBox(height: 24),
              const Center(child: Text('GULUF Taxi • Bosaso', style: TextStyle(color: Colors.black45, fontSize: 12))),
            ],
          ),
        ),
      );
}

class _RoleCard extends StatelessWidget {
  const _RoleCard({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
        elevation: 0,
        color: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          leading: CircleAvatar(backgroundColor: const Color(0xFFE4F3EC), child: Icon(icon, color: gulufGreen)),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Padding(padding: const EdgeInsets.only(top: 4), child: Text(subtitle)),
          trailing: const Icon(Icons.chevron_right),
          onTap: onTap,
        ),
      );
}

class PassengerPage extends StatefulWidget {
  const PassengerPage({super.key});
  @override
  State<PassengerPage> createState() => _PassengerPageState();
}

class _PassengerPageState extends State<PassengerPage> {
  final pickup = TextEditingController(text: 'Bartamaha Bosaso');
  final destination = TextEditingController();
  int fare = 3;

  @override
  void dispose() {
    pickup.dispose();
    destination.dispose();
    super.dispose();
  }

  void _createRide() {
    if (pickup.text.trim().isEmpty || destination.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Fadlan buuxi labada goobood.')));
      return;
    }
    RideStore.instance.createRide(
      pickup: pickup.text.trim(),
      destination: destination.text.trim(),
      fare: fare,
    );
    destination.clear();
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Dalabka waa la sameeyay'),
        content: Text('Lambarka dalabka: #${RideStore.instance.rides.first.id}\nKa: ${pickup.text.trim()}\nKu: ${RideStore.instance.rides.first.destination}\nQiime tijaabo ah: \$$fare\n\nDalabkani wuxuu ka muuqanayaa qaybta darawalka ee isla app-kan demo ahaan.'),
        actions: [FilledButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Haye'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('GULUF • Macmiil')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: gulufDark, borderRadius: BorderRadius.circular(20)),
              child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(Icons.location_on, color: Colors.white, size: 32),
                SizedBox(height: 12),
                Text('Xaggee ayaad u socotaa?', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                SizedBox(height: 6),
                Text('Geli meesha lagaa qaadayo iyo meesha aad u socoto.', style: TextStyle(color: Colors.white70)),
              ]),
            ),
            const SizedBox(height: 20),
            const Text('Meesha lagaa qaadayo', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextField(controller: pickup, textInputAction: TextInputAction.next, decoration: const InputDecoration(prefixIcon: Icon(Icons.my_location), hintText: 'Tusaale: Bartamaha Bosaso')),
            const SizedBox(height: 16),
            const Text('Meesha aad u socoto', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextField(controller: destination, textInputAction: TextInputAction.done, decoration: const InputDecoration(prefixIcon: Icon(Icons.location_on_outlined), hintText: 'Geli goobta aad u socoto')),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
              child: Row(children: [
                const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Qiime qiyaas ah', style: TextStyle(color: Colors.black54)),
                  SizedBox(height: 4),
                  Text('Dooro qiimaha tijaabada', style: TextStyle(fontWeight: FontWeight.bold)),
                ])),
                DropdownButton<int>(
                  value: fare,
                  items: const [
                    DropdownMenuItem(value: 3, child: Text('\$3')),
                    DropdownMenuItem(value: 5, child: Text('\$5')),
                    DropdownMenuItem(value: 7, child: Text('\$7')),
                    DropdownMenuItem(value: 10, child: Text('\$10')),
                  ],
                  onChanged: (value) => setState(() => fare = value ?? 3),
                ),
              ]),
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: gulufGreen, minimumSize: const Size.fromHeight(54)),
              icon: const Icon(Icons.local_taxi),
              label: const Text('Dalbo taxi', style: TextStyle(fontWeight: FontWeight.bold)),
              onPressed: _createRide,
            ),
            const SizedBox(height: 24),
            const Text('Safarradii ugu dambeeyey', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: gulufDark)),
            const SizedBox(height: 8),
            AnimatedBuilder(
              animation: RideStore.instance,
              builder: (context, _) {
                final rides = RideStore.instance.rides;
                if (rides.isEmpty) return const _EmptyPanel(message: 'Weli safar lama dalban.');
                return Column(children: rides.take(5).map((ride) => _RideCard(ride: ride, showDriverActions: false)).toList());
              },
            ),
            const SizedBox(height: 12),
            const Text('Ogow: qiimayaasha, dalabyada iyo xaaladaha safarku waa demo. App-ku weli kuma xirna darawallo dhab ah ama server online ah.', style: TextStyle(color: Colors.black54, fontSize: 12, height: 1.4)),
          ],
        ),
      );
}

class DriverPage extends StatelessWidget {
  const DriverPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('GULUF • Darawal')),
        body: AnimatedBuilder(
          animation: RideStore.instance,
          builder: (context, _) {
            final rides = RideStore.instance.rides;
            if (rides.isEmpty) {
              return const _EmptyPanel(message: 'Weli dalab ma jiro. Marka macmiilku dalab demo ah sameeyo, halkan ayuu ka muuqan doonaa.');
            }
            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Text('Dalabyada safarka', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: gulufDark)),
                const SizedBox(height: 12),
                for (final ride in rides) _RideCard(ride: ride, showDriverActions: true),
              ],
            );
          },
        ),
      );
}

class _RideCard extends StatelessWidget {
  const _RideCard({required this.ride, required this.showDriverActions});
  final Ride ride;
  final bool showDriverActions;

  @override
  Widget build(BuildContext context) {
    final store = RideStore.instance;
    final terminal = ride.status == RideStatus.completed ||
        ride.status == RideStatus.declined ||
        ride.status == RideStatus.cancelled;
    return Card(
      color: Colors.white,
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.route, color: gulufGreen),
            const SizedBox(width: 8),
            Expanded(child: Text('Dalab #${ride.id}', style: const TextStyle(fontWeight: FontWeight.w900))),
            Text('\$${ride.fare}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: gulufGreen)),
          ]),
          const SizedBox(height: 12),
          _RouteLine(icon: Icons.radio_button_checked, label: 'Laga qaadayo', value: ride.pickup),
          const SizedBox(height: 8),
          _RouteLine(icon: Icons.location_on, label: 'Meesha loo socdo', value: ride.destination),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: const Color(0xFFE4F3EC), borderRadius: BorderRadius.circular(20)),
            child: Text(ride.status.label, style: const TextStyle(color: gulufDark, fontWeight: FontWeight.w700, fontSize: 12)),
          ),
          if (showDriverActions && !terminal) ...[
            const SizedBox(height: 14),
            Wrap(spacing: 8, runSpacing: 8, children: [
              if (ride.status == RideStatus.requested) ...[
                FilledButton(onPressed: () => store.updateStatus(ride, RideStatus.accepted), child: const Text('Aqbal safarka')),
                OutlinedButton(onPressed: () => store.updateStatus(ride, RideStatus.declined), child: const Text('Diid')),
              ],
              if (ride.status == RideStatus.accepted)
                FilledButton.icon(onPressed: () => store.updateStatus(ride, RideStatus.onTrip), icon: const Icon(Icons.directions_car), label: const Text('Bilow safarka')),
              if (ride.status == RideStatus.onTrip)
                FilledButton.icon(onPressed: () => store.updateStatus(ride, RideStatus.completed), icon: const Icon(Icons.check_circle), label: const Text('Dhammee safarka')),
            ]),
          ],
        ]),
      ),
    );
  }
}

class _RouteLine extends StatelessWidget {
  const _RouteLine({required this.icon, required this.label, required this.value});
  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, size: 19, color: gulufGreen),
        const SizedBox(width: 8),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(color: Colors.black54, fontSize: 12)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
        ])),
      ]);
}

class AdminPage extends StatelessWidget {
  const AdminPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Maamulka GULUF')),
        body: AnimatedBuilder(
          animation: RideStore.instance,
          builder: (context, _) {
            final rides = RideStore.instance.rides;
            final total = rides.where((r) => r.status == RideStatus.completed).fold<int>(0, (sum, ride) => sum + ride.fare);
            final active = rides.where((r) => r.status == RideStatus.requested || r.status == RideStatus.accepted || r.status == RideStatus.onTrip).length;
            return ListView(padding: const EdgeInsets.all(20), children: [
              const Text('Warbixinta guud', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: gulufDark)),
              const SizedBox(height: 6),
              const Text('Tirooyinkani waa xog demo oo ku jirta xusuusta app-ka.', style: TextStyle(color: Colors.black54)),
              const SizedBox(height: 18),
              Row(children: [
                Expanded(child: _StatCard(label: 'Safarrada', value: '${rides.length}', icon: Icons.route)),
                const SizedBox(width: 10),
                Expanded(child: _StatCard(label: 'Socda/ cusub', value: '$active', icon: Icons.local_taxi)),
              ]),
              const SizedBox(height: 10),
              _StatCard(label: 'Qiimaha safarrada dhammaaday', value: '\$$total', icon: Icons.payments),
              const SizedBox(height: 20),
              const Text('Dhammaan dalabyada', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              const SizedBox(height: 8),
              if (rides.isEmpty)
                const _EmptyPanel(message: 'Dalabyo wali lama helin.')
              else
                for (final ride in rides) _RideCard(ride: ride, showDriverActions: false),
              const SizedBox(height: 12),
              const Text('Ka hor isticmaalka dhabta ah waxaa loo baahan yahay server/database online ah, login ammaan ah, GPS iyo khariidad, ogeysiisyo, qiime rasmi ah, tijaabo qalab iyo ilaalinta xogta.', style: TextStyle(color: Colors.black54, height: 1.4)),
            ]);
          },
        ),
      );
}

class _EmptyPanel extends StatelessWidget {
  const _EmptyPanel({required this.message});
  final String message;

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.local_taxi, size: 54, color: gulufGreen),
            const SizedBox(height: 12),
            const Text('GULUF TAXI', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(message, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)),
          ]),
        ),
      );
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.label, required this.value, required this.icon});
  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: gulufGreen, size: 26),
          const SizedBox(height: 12),
          Text(value, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: gulufDark)),
          Text(label, style: const TextStyle(color: Colors.black54)),
        ]),
      );
}
